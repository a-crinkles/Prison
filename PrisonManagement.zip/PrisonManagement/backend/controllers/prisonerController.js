const prisoners = [

{
    'id' : 1,
    'name': 'Nico',
    'age': 22,
    'crime': 'Possesion of Illegal Drugs',
    'sentence': '15 years',
},

{
    'id' : 2,
    'name': 'Arabella',
    'age': 19,
    'crime': 'Serial Murder',
    'sentence': '30 years',
},
{
    'id' : 3,
    'name': 'Bianca',
    'age': 20,
    'crime': 'Adultery',
    'sentence': '10 years',
}

]

module.exports.prisoners = (req, res) => {
    res.json ({'PRISONERS': prisoners});

};

// http://localhost:4000/p/prisoners
module.exports.prisoner = (req, res) => {
    const {id} = req.params
    console.log(id)
    const matchinPrisoner = prisoners.filter (
        (prisoner) => prisoner.id === parseInt (id)

    )

    if (matchinPrisoner.length === 0){
        res.status(404).json({ 'error': `Prisoner with ID ${id} not found` });
    }

    else {
        res.status (200).json({'prisoner': matchinPrisoner[0]})
    }
}

// http://localhost:4000/p/greet/person?name=Arabella
module.exports.greet= (req, res) => {
    const {name} = req.query
    console.log(name)
    res.status(200).json ({'HELLO': name})

}

// http://localhost:4000/p/search/prisoner?id=3&name=Bianca
module.exports.searchPrisoner= (req, res) => {
    const {id, name} = req.query
    console.log(id, name)
    const matchinPrisoner = prisoners.filter(
        (p) => p.id === parseInt(id) && p.name === name
    )

    if (matchinPrisoner.length === 0){
        res.status(404).json({ 'error': `Prisoner with ID ${id} and name ${name} not found` });

    }
    else (
        res.status(200).json({'found' : matchinPrisoner[0]})
    )
}
