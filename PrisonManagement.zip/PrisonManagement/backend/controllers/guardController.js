const guards = [
    {
        'id' : 1,
        'name': 'Jamberlu',
        'rank': 'Captain',
        'years of service' : 40
    },

    {
        'id' : 2,
        'name': 'Skibidi',
        'rank': 'Chief',
        'years of service' : 50
    },

    {
        'id' : 3,
        'name': 'Hamberski',
        'rank': 'Sergeant',
        'years of service' : 35
    },

    {
        'id' : 4,
        'name': 'Ankie',
        'rank': 'Security Guard',
        'years of service' : 25
    }
]

// http://localhost:4000/g/guards
module.exports.guards = (req, res) => {
    res.json ({'GUARDS': guards});

};

// http://localhost:4000/g/guard/3
module.exports.guard = (req, res) => {
    const {id} = req.params
    console.log(id)
    const matchinGuard = guards.filter (
        (guard) => guard.id === parseInt (id)

    )

    if (matchinGuard.length === 0){
        res.status(404).json({'error': `Guard with ID $(id) not found`})
    }

    else {
        res.status (200).json({'guard': matchinGuard[0]})
    }
}

// http://localhost:4000/g/search/guard?id=2&rank=Chief&yearsOfService=50
module.exports.searchGuard= (req, res) => {
    const {id, rank, yearsOfService } = req.query
    console.log(id, rank, yearsOfService)
    const matchinGuard = guards.filter(
        (g) => g.id === parseInt(id) && g.rank === rank && g['years of service'] === parseInt (yearsOfService)
    )

    if (matchinGuard.length === 0){
        res.status(404).json({ 'error': `Guard with ID ${id}, rank ${rank}, and ${yearsOfService} years of service not found`});
    }
    else (
        res.status(200).json({'found' : matchinGuard[0]})
    )
}

// http://localhost:4000/g/delete/3
// http://localhost:4000/g/guards
module.exports.deleteGuard = (req, res) => {
    const {id} = req.params;
    const index = guards.findIndex(guard => guard.id === parseInt(id));

    if (index === -1) {
        res.status(404).json({ 'error': `Guard with ID ${id} not found` });
    } else {
        const deletedGuard = guards[index];
        guards.splice(index, 1);
        res.status(200).json({ 'success': `Guard with ID ${id} deleted successfully`, 'deletedGuard': deletedGuard });
    }
}
