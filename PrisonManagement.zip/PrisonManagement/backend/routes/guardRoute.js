const express = require ('express')
const router = express.Router()

const guardController = require('../controllers/guardController')

// get all list of guards
router.get('/guards', guardController.guards)

// get guards with id
router.get('/guard/:id', guardController.guard)

// get guards with id, rank, years of service
router.get('/search/guard', guardController.searchGuard)

// delete the information of guards
router.get('/delete/:id', guardController.deleteGuard);

module.exports = router;